let questions = [{
        numb: 1,
        question: "Apa warna kerusakaan gua?",
        answer: "Biru",
        options: [
            "Hijau",
            "Biru Tua",
            "Biru muda",
            "Biru"
        ]
    },
    {
        numb: 2,
        question: "Kapan gua ultah?",
        answer: "23 Juni",
        options: [
            "23 Juli",
            "23 Juni",
            "23 April",
            "23 November"
        ]
    },
    {
        numb: 3,
        question: "Gua kelahiran taun berapa?",
        answer: "2008",
        options: [
            "2007",
            "2006",
            "2005",
            "2008"
        ]
    },
    {
        numb: 4,
        question: "Apa hobby gua??",
        answer: "Bola",
        options: [
            "Coding",
            "Bola",
            "Futsal",
            "Bulu Tangkis"
        ]
    },
    {
        numb: 5,
        question: "Apa makanan kesukaan gua?",
        answer: "Mie & Maklor",
        options: [
            "Telor & Cumi",
            "Mie & Maklor",
            "Nasgor & Mie",
            "Sate & Bakso"
        ]
    },
    {
        numb: 6,
        question: "Dijurusan apa gua sekarang?",
        answer: "TKJ",
        options: [
            "TKJ",
            "MP",
            "AK",
            "RPL"
        ]
    },
    {
        numb: 7,
        question: "Nama hospot gua?",
        answer: "1+1 =",
        options: [
            "1+1 =",
            "Samalekom",
            "Apaja",
            "Kay123"
        ]
    },
    {
        numb: 8,
        question: "Sandi hospot gua?",
        answer: "sama dengan d2a",
        options: [
            "sama dengan d2a",
            "sama dengan dua",
            "sama = dua",
            "sama = 2"
        ]
    },
];